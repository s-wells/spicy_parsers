# CDP Spicy Analyzer Package Summary

## Overview
This package provides a complete Cisco Discovery Protocol (CDP) analyzer for Zeek using the Spicy parser generator. CDP is a Cisco proprietary Layer 2 protocol used for device discovery and neighbor information sharing.

## Package Structure

```
spicy-cdp/
├── analyzer/               # Core analyzer files
│   ├── cdp.spicy          # Spicy grammar defining CDP packet structure
│   ├── cdp.evt            # Event definitions for Zeek integration
│   └── dpd.sig            # Dynamic Protocol Detection signature
├── scripts/               # Zeek scripts
│   ├── __load__.zeek      # Package loader
│   └── main.zeek          # Main CDP event handlers and logging
├── CMakeLists.txt         # Build configuration
├── zkg.meta              # Zeek package manager metadata
├── README.md             # User documentation
├── TLV_REFERENCE.md      # CDP TLV type reference
└── cdp-example.zeek      # Example usage script
```

## Key Components

### 1. cdp.spicy - Grammar Definition
Defines the CDP packet structure using Spicy:
- **Packet header**: Version (1 byte), TTL (1 byte), Checksum (2 bytes)
- **TLV structures**: Generic Type-Length-Value parsing
- **Specialized TLVs**: Device ID, Port ID, Platform, Capabilities, etc.
- **Complex types**: Address lists, Protocol Hello structures

Key features:
- Supports CDP versions 1 and 2
- Parses all common TLV types
- Gracefully handles unknown TLV types
- Uses `&eod` (end-of-data) for variable-length TLV arrays

### 2. cdp.evt - Zeek Integration
Connects Spicy parser to Zeek:
- Defines packet analyzer `spicy::CDP`
- Generates events for each TLV type
- Maps Spicy types to Zeek types
- No connection parameter (packet analyzer, not protocol analyzer)

Events generated:
- `zeek_cdp_packet` - Main packet header
- `zeek_cdp_device_id` - Device hostname/serial
- `zeek_cdp_port_id` - Interface name
- `zeek_cdp_platform` - Hardware platform
- `zeek_cdp_capabilities` - Device capabilities
- And more for each TLV type...

### 3. main.zeek - Event Handlers
Zeek script that:
- Creates CDP log stream
- Defines CDP::Info record type
- Handles all CDP events
- Aggregates TLV data into single log entry
- Writes to `cdp.log`

### 4. dpd.sig - Protocol Detection
Signature for automatic protocol detection:
- Matches LLC/SNAP header pattern
- OUI: 0x00000C (Cisco)
- Protocol ID: 0x2000 (CDP)
- Enables spicy::CDP analyzer when matched

## CDP Protocol Details

### Encapsulation
- Layer 2 protocol (no IP/TCP/UDP)
- LLC/SNAP header: `AA AA 03 00 00 0C 20 00`
- Multicast destination MAC: `01:00:0C:CC:CC:CC`

### Packet Structure
```
+----------+----------+-----------+
| Version  |   TTL    | Checksum  |
| (1 byte) | (1 byte) | (2 bytes) |
+----------+----------+-----------+
|         TLV #1                  |
+---------------------------------+
|         TLV #2                  |
+---------------------------------+
|           ...                   |
+---------------------------------+
```

### TLV Structure
```
+-------------+-------------+
|    Type     |   Length    |
|  (2 bytes)  |  (2 bytes)  |
+-------------+-------------+
|         Value             |
|       (variable)          |
+---------------------------+
```

## Installation & Usage

### Install with zkg
```bash
zkg install /path/to/spicy-cdp
```

### Manual Build
```bash
cd spicy-cdp
mkdir build && cd build
cmake .. -DCMAKE_INSTALL_PREFIX=/usr/local/zeek
make
make install
```

### Use in Zeek
```bash
# Load in script
@load spicy-cdp

# Run on pcap
zeek -r cdp_traffic.pcap spicy-cdp

# With example script
zeek -r cdp_traffic.pcap cdp-example.zeek
```

## Log Output

The analyzer generates `cdp.log` with fields:
- `ts` - Timestamp
- `version` - CDP version (1 or 2)
- `ttl` - Hold time in seconds
- `device_id` - Device hostname/serial
- `port_id` - Interface name
- `software_version` - IOS version
- `platform` - Hardware model
- `capabilities` - Capability bitmask
- `native_vlan` - Native VLAN ID
- `duplex` - Duplex setting
- `vtp_domain` - VTP domain name
- `mtu` - Interface MTU
- `num_addresses` - Number of advertised addresses

## Capability Flags Decoding

The capabilities field is a 32-bit bitmask:
```
0x001 - Router
0x002 - Transparent Bridge
0x004 - Source Route Bridge
0x008 - Switch
0x010 - Host
0x020 - IGMP
0x040 - Repeater
0x080 - VoIP Phone
0x100 - Remotely Managed Device
0x200 - CVTA/VoIP Gateway
0x400 - Two-Port MAC Relay
```

## Design Decisions

### 1. Packet Analyzer vs Protocol Analyzer
CDP is a packet analyzer because:
- Operates at Layer 2 (below IP)
- No connection concept
- Events have no connection parameter
- Uses DPD signature for detection

### 2. Event-Driven Architecture
- Separate events for each TLV type
- Allows selective event handling
- Current packet state tracked globally
- Log written when address TLV completes (typically last)

### 3. TLV Parsing Strategy
- Generic TLV structure with switch statement
- Type-specific parsing in switch arms
- Unknown types captured as `raw_data`
- Length-based skipping for forward compatibility

### 4. String Encoding
- ASCII charset for text TLVs
- Handles device names, interface names, versions
- Platform-independent

## Testing Recommendations

1. **Capture Real CDP Traffic**:
   ```bash
   tcpdump -i eth0 -w cdp.pcap ether dst 01:00:0c:cc:cc:cc
   ```

2. **Test with Wireshark First**:
   Verify packet structure before running through Zeek

3. **Check Both CDPv1 and CDPv2**:
   Different Cisco IOS versions send different formats

4. **Verify TLV Parsing**:
   Check logs contain expected fields

## Future Enhancements

Possible improvements:
1. Parse individual addresses from ADDRESSES TLV
2. Decode Protocol Hello (Cluster Management)
3. Handle IP Prefix TLV for ODR
4. Parse Location TLV (LLDP-MED format)
5. Add NOTICE for CDP spoofing detection
6. Support for CDP over other encapsulations (HDLC, PPP)

## References

- [Zeek Spicy Documentation](https://docs.zeek.org/projects/spicy/)
- [CDP Wikipedia](https://en.wikipedia.org/wiki/Cisco_Discovery_Protocol)
- [Wireshark CDP Wiki](https://wiki.wireshark.org/CDP)
- Cisco IOS Documentation

## Compliance & Security

**Note**: CDP can be a security risk:
- Exposes network topology
- Reveals device information
- Subject to spoofing attacks
- Often disabled in production networks

This analyzer is for **monitoring and analysis** purposes.

## License
BSD-3-Clause (adjust as needed)
