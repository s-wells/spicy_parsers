##! Example script showing how to use the CDP analyzer
##!
##! Usage: zeek -r cdp_traffic.pcap cdp-example.zeek

@load spicy-cdp

# Optional: Add custom CDP event handlers
event zeek_cdp_device_id(device_id: string) {
    print fmt("Detected CDP device: %s", device_id);
}

event zeek_cdp_capabilities(capabilities: count) {
    # Decode capability flags
    local caps: vector of string = vector();
    
    if ( capabilities & 0x01 )
        caps += "Router";
    if ( capabilities & 0x02 )
        caps += "Transparent-Bridge";
    if ( capabilities & 0x04 )
        caps += "Source-Route-Bridge";
    if ( capabilities & 0x08 )
        caps += "Switch";
    if ( capabilities & 0x10 )
        caps += "Host";
    if ( capabilities & 0x20 )
        caps += "IGMP";
    if ( capabilities & 0x40 )
        caps += "Repeater";
    if ( capabilities & 0x80 )
        caps += "VoIP-Phone";
    if ( capabilities & 0x100 )
        caps += "Remotely-Managed";
    if ( capabilities & 0x200 )
        caps += "CVTA";
    if ( capabilities & 0x400 )
        caps += "Two-Port-MAC-Relay";
    
    print fmt("Device capabilities: %s", join_string_vec(caps, ", "));
}
