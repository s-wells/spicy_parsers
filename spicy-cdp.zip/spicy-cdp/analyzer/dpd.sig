# Signature to detect CDP packets over LLC/SNAP
# CDP uses OUI 0x00000C and protocol ID 0x2000

# Match on the SNAP header that indicates CDP
# LLC header: DSAP=0xAA, SSAP=0xAA, Control=0x03
# SNAP header: OUI=0x00000C, PID=0x2000
signature dpd_cdp_snap {
  ip-proto == raw
  payload /^\xaa\xaa\x03\x00\x00\x0c\x20\x00/
  enable "spicy::CDP"
}
