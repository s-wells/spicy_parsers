##! CDP (Cisco Discovery Protocol) analyzer for Zeek
##!
##! This script processes CDP packets and generates logs with neighbor information

module CDP;

export {
    redef enum Log::ID += { LOG };

    ## CDP log record
    type Info: record {
        ## Timestamp when the CDP packet was seen
        ts:                time            &log;
        ## CDP version (1 or 2)
        version:          count           &log;
        ## TTL/Holdtime in seconds
        ttl:              count           &log;
        ## Device ID (hostname or serial number)
        device_id:        string          &log &optional;
        ## Port ID (interface name)
        port_id:          string          &log &optional;
        ## Software version string
        software_version: string          &log &optional;
        ## Hardware platform
        platform:         string          &log &optional;
        ## Device capabilities as bitmask
        capabilities:     count           &log &optional;
        ## Native VLAN ID
        native_vlan:      count           &log &optional;
        ## Duplex setting (0=half, 1=full)
        duplex:           count           &log &optional;
        ## VTP management domain
        vtp_domain:       string          &log &optional;
        ## Interface MTU
        mtu:              count           &log &optional;
        ## Number of addresses advertised
        num_addresses:    count           &log &optional;
    };

    ## Event raised when a complete CDP packet is parsed
    global zeek_cdp_packet: event(version: count, ttl: count, checksum: count);
    
    ## Event raised for Device ID TLV
    global zeek_cdp_device_id: event(device_id: string);
    
    ## Event raised for Port ID TLV
    global zeek_cdp_port_id: event(port_id: string);
    
    ## Event raised for Software Version TLV
    global zeek_cdp_software_version: event(software_version: string);
    
    ## Event raised for Platform TLV
    global zeek_cdp_platform: event(platform: string);
    
    ## Event raised for Capabilities TLV
    global zeek_cdp_capabilities: event(capabilities: count);
    
    ## Event raised for Native VLAN TLV
    global zeek_cdp_native_vlan: event(native_vlan: count);
    
    ## Event raised for Duplex TLV
    global zeek_cdp_duplex: event(duplex: count);
    
    ## Event raised for VTP Domain TLV
    global zeek_cdp_vtp_domain: event(vtp_domain: string);
    
    ## Event raised for MTU TLV
    global zeek_cdp_mtu: event(mtu: count);
    
    ## Event raised for Addresses TLV
    global zeek_cdp_addresses: event(num_addresses: count);
}

# Track current CDP packet being processed
global current_cdp: Info;

event zeek_init() &priority=5 {
    Log::create_stream(CDP::LOG, [$columns=Info, $path="cdp"]);
}

event zeek_cdp_packet(version: count, ttl: count, checksum: count) {
    current_cdp = Info();
    current_cdp$ts = network_time();
    current_cdp$version = version;
    current_cdp$ttl = ttl;
}

event zeek_cdp_device_id(device_id: string) {
    current_cdp$device_id = device_id;
}

event zeek_cdp_port_id(port_id: string) {
    current_cdp$port_id = port_id;
}

event zeek_cdp_software_version(software_version: string) {
    current_cdp$software_version = software_version;
}

event zeek_cdp_platform(platform: string) {
    current_cdp$platform = platform;
}

event zeek_cdp_capabilities(capabilities: count) {
    current_cdp$capabilities = capabilities;
}

event zeek_cdp_native_vlan(native_vlan: count) {
    current_cdp$native_vlan = native_vlan;
}

event zeek_cdp_duplex(duplex: count) {
    current_cdp$duplex = duplex;
}

event zeek_cdp_vtp_domain(vtp_domain: string) {
    current_cdp$vtp_domain = vtp_domain;
}

event zeek_cdp_mtu(mtu: count) {
    current_cdp$mtu = mtu;
}

event zeek_cdp_addresses(num_addresses: count) {
    current_cdp$num_addresses = num_addresses;
    
    # Log the completed CDP entry
    Log::write(CDP::LOG, current_cdp);
}
