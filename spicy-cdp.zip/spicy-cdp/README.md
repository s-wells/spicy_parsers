# CDP Analyzer for Zeek

This package provides a Cisco Discovery Protocol (CDP) analyzer for Zeek, implemented using the Spicy parser generator.

## About CDP

Cisco Discovery Protocol (CDP) is a proprietary Layer 2 network protocol developed by Cisco Systems. It is used by Cisco devices to share information about other directly connected Cisco equipment.

### Key Features:
- Runs at Layer 2 (Data Link Layer)
- Multicast destination MAC: `01:00:0C:CC:CC:CC`
- Encapsulated in LLC/SNAP with OUI `0x00000C` and protocol ID `0x2000`
- Sends advertisements every 60 seconds by default
- Default holdtime of 180 seconds

## Installation

### Using zkg (Zeek Package Manager)

```bash
zkg install /path/to/spicy-cdp
```

### Manual Installation

1. Build the package:
```bash
cd spicy-cdp
mkdir build && cd build
cmake .. -DCMAKE_INSTALL_PREFIX=/usr/local/zeek
make
make install
```

2. Load the analyzer in your Zeek script:
```zeek
@load spicy-cdp
```

## Parsed Information

The analyzer extracts the following CDP TLV (Type-Length-Value) fields:

- **Device ID**: Hostname or hardware serial number
- **Port ID**: Interface name sending the CDP packet
- **Software Version**: IOS/software version running on the device
- **Platform**: Hardware platform (e.g., WS-C3548-XL, Cisco 2960)
- **Capabilities**: Device functional capabilities (router, switch, phone, etc.)
- **Addresses**: Network layer addresses
- **Native VLAN**: The untagged VLAN on the interface
- **Duplex**: Half or full duplex setting
- **VTP Management Domain**: VLAN Trunking Protocol domain
- **MTU**: Maximum Transmission Unit
- **Power Information**: PoE power draw and availability

## Log Format

CDP events are logged to `cdp.log` with the following fields:

| Field | Type | Description |
|-------|------|-------------|
| ts | time | Timestamp of CDP packet |
| src_mac | string | Source MAC address |
| dst_mac | string | Destination MAC address |
| version | count | CDP version (1 or 2) |
| ttl | count | Hold time in seconds |
| device_id | string | Device hostname/ID |
| port_id | string | Interface name |
| software_version | string | Software version |
| platform | string | Hardware platform |
| capabilities | count | Capability flags bitmask |
| native_vlan | count | Native VLAN ID |
| duplex | count | Duplex setting |
| vtp_domain | string | VTP domain name |
| mtu | count | Interface MTU |
| num_addresses | count | Number of addresses |

## Capability Flags

The capabilities field is a bitmask with the following values:

- `0x01` - Router
- `0x02` - Transparent Bridge
- `0x04` - Source Route Bridge
- `0x08` - Switch
- `0x10` - Host
- `0x20` - IGMP
- `0x40` - Repeater
- `0x80` - VoIP Phone
- `0x100` - Remotely Managed Device
- `0x200` - CVTA/VoIP Gateway
- `0x400` - Two-Port Mac Relay

## Testing

You can test the analyzer with CDP traffic:

```bash
zeek -C -r cdp_sample.pcap spicy-cdp
```

## Notes

- CDP is disabled by default on many modern networks for security reasons
- CDP packets are never forwarded by switches/routers
- CDPv2 adds additional TLVs compared to CDPv1 (Native VLAN, Duplex, VTP Domain)
- This analyzer works at the packet level, so it requires raw packet capture

## References

- [Cisco Discovery Protocol Wikipedia](https://en.wikipedia.org/wiki/Cisco_Discovery_Protocol)
- [Wireshark CDP Wiki](https://wiki.wireshark.org/CDP)
- [Spicy Documentation](https://docs.zeek.org/projects/spicy/)

## License

BSD-3-Clause (or your preferred license)

## Contributing

Contributions welcome! Please submit issues and pull requests.
