# CDP TLV (Type-Length-Value) Reference

This document provides a comprehensive reference of CDP TLV types.

## TLV Structure

All CDP TLVs follow this format:
- **Type** (2 bytes): Identifies the TLV type
- **Length** (2 bytes): Total length including Type and Length fields
- **Value** (variable): The actual data

## Supported TLV Types

### 0x0001 - Device ID
**CDPv1/v2**
- **Format**: ASCII string
- **Description**: Hostname or hardware serial number of the device
- **Example**: "Switch01", "FOC1234ABCD"

### 0x0002 - Addresses
**CDPv1/v2**
- **Format**: Complex structure
  - Number of addresses (4 bytes)
  - For each address:
    - Protocol type (1 byte)
    - Protocol length (1 byte)
    - Protocol (variable)
    - Address length (2 bytes)
    - Address (variable)
- **Description**: Network layer addresses (typically IP addresses)

### 0x0003 - Port ID
**CDPv1/v2**
- **Format**: ASCII string
- **Description**: Interface name from which CDP was sent
- **Example**: "GigabitEthernet0/1", "FastEthernet1/0/24"

### 0x0004 - Capabilities
**CDPv1/v2**
- **Format**: 4-byte bitmask
- **Description**: Functional capabilities of the device
- **Flags**:
  - `0x01` - Router
  - `0x02` - Transparent Bridge
  - `0x04` - Source Route Bridge
  - `0x08` - Switch
  - `0x10` - Host
  - `0x20` - IGMP capable
  - `0x40` - Repeater
  - `0x80` - VoIP Phone
  - `0x100` - Remotely Managed Device
  - `0x200` - CVTA/VoIP Gateway
  - `0x400` - Two-Port MAC Relay

### 0x0005 - Software Version
**CDPv1/v2**
- **Format**: ASCII string
- **Description**: IOS version or software release information
- **Example**: "Cisco IOS Software, C2960 Software..."

### 0x0006 - Platform
**CDPv1/v2**
- **Format**: ASCII string
- **Description**: Hardware platform model
- **Example**: "cisco WS-C2960-24TT-L", "Cisco IP Phone 7960"

### 0x0007 - IP Prefix/Gateway
**CDPv1**
- **Format**: 4 bytes IPv4 prefix + 1 byte CIDR mask
- **Description**: Used for ODR (On-Demand Routing)

### 0x0008 - Protocol Hello
**CDPv1/v2**
- **Format**: Complex structure
- **Description**: Cluster Management Protocol information
- **Contains**: OUI, Protocol ID, Cluster Master IP, etc.

### 0x0009 - VTP Management Domain
**CDPv2**
- **Format**: ASCII string
- **Description**: VLAN Trunking Protocol management domain name
- **Example**: "production", "lab"

### 0x000a - Native VLAN
**CDPv2**
- **Format**: 2 bytes
- **Description**: The native (untagged) VLAN ID on the interface
- **Example**: 1 (default), 100

### 0x000b - Duplex
**CDPv2**
- **Format**: 1 byte
- **Description**: Duplex setting of the port
- **Values**:
  - `0x00` - Half duplex
  - `0x01` - Full duplex

### 0x000e - VoIP VLAN Reply
**CDPv2**
- **Format**: 2 bytes
- **Description**: Response to VoIP VLAN query, specifies voice VLAN ID
- **Used by**: IP Phones

### 0x000f - VoIP VLAN Query
**CDPv2**
- **Format**: 1 byte
- **Description**: Query for voice VLAN information
- **Used by**: IP Phones

### 0x0010 - Power Consumption
**CDPv2**
- **Format**: 2 bytes (milliwatts)
- **Description**: Power drawn by the device (PoE)
- **Example**: 6500 (6.5 watts)

### 0x0011 - MTU
**CDPv2**
- **Format**: 4 bytes
- **Description**: Maximum Transmission Unit of the interface
- **Example**: 1500

### 0x0012 - Trust Bitmap
**CDPv2**
- **Format**: 1 byte
- **Description**: Trust configuration for QoS

### 0x0013 - Untrusted Port CoS
**CDPv2**
- **Format**: 1 byte
- **Description**: Class of Service for untrusted ports

### 0x0014 - System Name
**CDPv2**
- **Format**: ASCII string
- **Description**: System name (SNMP sysName)

### 0x0015 - System Object ID
**CDPv2**
- **Format**: Binary OID
- **Description**: SNMP System Object Identifier

### 0x0016 - Management Address
**CDPv2**
- **Format**: Address structure
- **Description**: Management IP address

### 0x0017 - Location
**CDPv2**
- **Format**: ASCII string or TLV structure
- **Description**: Physical location information (LLDP-MED compatible)

### 0x0018 - External Port ID
**CDPv2**
- **Format**: ASCII string
- **Description**: External port identifier

### 0x0019 - Power Requested
**CDPv2**
- **Format**: 2 bytes (milliwatts)
- **Description**: Power requested by powered device
- **Used for**: PoE negotiation

### 0x001a - Power Available
**CDPv2**
- **Format**: 2 bytes (milliwatts)
- **Description**: Power available from power source
- **Used for**: PoE capability advertising

### 0x001b - Port Unidirectional
**CDPv2**
- **Format**: Variable
- **Description**: Indicates unidirectional link detection

### 0x001c - Application
**CDPv2**
- **Format**: Complex structure
- **Description**: Application-specific TLV (extensible)

## CDPv1 vs CDPv2

**CDPv1** supports:
- Device ID (0x0001)
- Addresses (0x0002)
- Port ID (0x0003)
- Capabilities (0x0004)
- Software Version (0x0005)
- Platform (0x0006)
- IP Prefix (0x0007)

**CDPv2** adds:
- VTP Management Domain (0x0009)
- Native VLAN (0x000a)
- Duplex (0x000b)
- VoIP VLAN support (0x000e, 0x000f)
- Power information (0x0010, 0x0019, 0x001a)
- MTU (0x0011)
- Additional management fields

## Notes

- TLVs can appear in any order
- Not all TLVs are present in every CDP packet
- Unknown TLV types should be safely skipped using the length field
- Some TLVs are mandatory (Device ID, Port ID, Capabilities)
- The actual TLVs present depend on device type and configuration

## References

- Cisco Discovery Protocol specification (proprietary)
- Wireshark CDP dissector
- CISCO-CDP-MIB (SNMP MIB)
