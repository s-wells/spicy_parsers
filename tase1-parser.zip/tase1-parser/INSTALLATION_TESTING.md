# TASE.1 Parser - Installation & Testing Guide

## Complete Installation Steps

### Prerequisites Check

```bash
# Check Zeek installation
zeek --version
# Should show Zeek 5.0 or later

# Check Spicy installation
spicyc --version
# Should show Spicy 1.6 or later

# Check CMake
cmake --version
# Should show 3.15 or later
```

### Installation Option 1: Zeek Package Manager (Recommended)

```bash
# Navigate to the parser directory
cd tase1-parser

# Install using zkg
zkg install .

# Verify installation
zeek -NN Zeek::Spicy | grep -i tase

# You should see:
# Zeek::Spicy::TASE1 - TASE.1/ICCP protocol analyzer (dynamic)
```

### Installation Option 2: Manual Build

```bash
# Navigate to parser directory
cd tase1-parser

# Configure (adjust path to your Zeek installation)
./configure --zeek-dist=/opt/zeek/src

# Alternative: if Zeek is installed system-wide
./configure --prefix=/usr/local/zeek

# Build
cd build
make -j$(nproc)

# Install (may require sudo)
sudo make install

# Verify installation
zeek -NN | grep -i tase
```

### Troubleshooting Installation

#### Issue: "Cannot find Zeek"
```bash
# Set Zeek path explicitly
export PATH=/opt/zeek/bin:$PATH
./configure --zeek-dist=/opt/zeek/src
```

#### Issue: "Cannot find Spicy"
```bash
# Ensure spicyc is in PATH
which spicyc

# If not found, install Spicy
# https://docs.zeek.org/projects/spicy/en/latest/installation.html
```

#### Issue: CMake errors
```bash
# Clean and rebuild
rm -rf build
mkdir build
cd build
cmake .. -DCMAKE_INSTALL_PREFIX=/usr/local/zeek
make
```

## Testing the Parser

### Test 1: Verify Parser Loads

```bash
# Check if analyzer is available
zeek -NN Zeek::Spicy | grep TASE1

# Expected output:
# Zeek::Spicy::TASE1 - TASE.1/ICCP protocol analyzer
```

### Test 2: Basic Functionality Test

```bash
# Create a test script
cat > test_basic.zeek << 'EOF'
@load tase1-parser

event zeek_init() {
    print "TASE.1 parser loaded successfully";
}

event tase1_connection_request(c: connection, src_ref: count, dst_ref: count, class_option: count) {
    print fmt("Connection request detected: %s -> %s", c$id$orig_h, c$id$resp_h);
}
EOF

# Run test (will wait for traffic or timeout)
timeout 5 zeek -i lo test_basic.zeek
```

### Test 3: PCAP Analysis Test

If you have a TASE.1 PCAP file:

```bash
# Analyze PCAP
zeek -r your_tase1_traffic.pcap tase1-parser

# Check for generated logs
ls -lh tase1.log

# View log contents
cat tase1.log | column -t

# Count events by type
cut -f9 tase1.log | sort | uniq -c
```

### Test 4: Synthetic Traffic Test

Since TASE.1 traffic may not be readily available:

```bash
# Use the included test script
zeek -r /path/to/test.pcap tests/test.zeek

# Or create synthetic test data (advanced)
# You would need a TASE.1 simulator or recorded traffic
```

### Test 5: Advanced Analysis Test

```bash
# Run with advanced analysis
zeek -r traffic.pcap tase1-parser scripts/examples/advanced_analysis.zeek

# Check output for statistics
# Should show operation counts and connection summaries
```

## Verification Checklist

- [ ] Parser loads without errors: `zeek -NN | grep TASE1`
- [ ] Can run basic script: `zeek test_basic.zeek`
- [ ] Logs are created: `tase1.log` exists
- [ ] Events are triggered: Check for console output with test script
- [ ] No Spicy parsing errors in stderr
- [ ] Can load in local.zeek: `@load tase1-parser`

## Integration Testing

### Add to Zeek's local.zeek

```bash
# Edit local.zeek
sudo nano /usr/local/zeek/share/zeek/site/local.zeek

# Add at the end:
@load tase1-parser

# Optional: Configure thresholds
redef TASE1::error_threshold = 10;
redef TASE1::request_rate_threshold = 100;
```

### Test with Zeek Manager

```bash
# Check configuration
zeekctl check

# Deploy changes
zeekctl deploy

# Check status
zeekctl status

# View logs
tail -f /usr/local/zeek/logs/current/tase1.log
```

## Performance Testing

### Monitor Resource Usage

```bash
# Run with performance monitoring
time zeek -r large_traffic.pcap tase1-parser

# Monitor memory usage
/usr/bin/time -v zeek -r large_traffic.pcap tase1-parser
```

### Stress Test

```bash
# Process multiple PCAPs
for pcap in *.pcap; do
    echo "Processing $pcap..."
    zeek -r "$pcap" tase1-parser
done
```

## Debugging

### Enable Spicy Debug Output

```bash
# See detailed parsing information
zeek -r test.pcap tase1-parser Spicy::enable_print=T
```

### Enable Zeek Debug Logging

```bash
# Verbose Zeek output
zeek -B dpd -r test.pcap tase1-parser
```

### Check for Parser Errors

```bash
# Capture stderr
zeek -r test.pcap tase1-parser 2>&1 | grep -i error

# Check for warnings
zeek -r test.pcap tase1-parser 2>&1 | grep -i warning
```

## Common Issues and Solutions

### 1. No tase1.log Generated

**Cause**: No TASE.1 traffic on port 102

**Solution**:
```bash
# Verify PCAP contains port 102 traffic
tcpdump -r your_file.pcap 'tcp port 102' -c 10

# Try with different port if needed (modify analyzer)
```

### 2. Parser Not Recognized

**Cause**: Installation path issue

**Solution**:
```bash
# Check Zeek plugin directory
zeek-config --plugin_dir

# Verify parser is installed there
ls -la $(zeek-config --plugin_dir)/packages/tase1-parser/
```

### 3. Spicy Compilation Errors

**Cause**: Syntax errors in grammar

**Solution**:
```bash
# Test Spicy grammar directly
spicyc src/tase1.spicy

# Check for errors
```

### 4. Events Not Firing

**Cause**: Event definitions mismatch

**Solution**:
```bash
# Verify .evt file syntax
cat src/tase1.evt

# Ensure event names match in .zeek script
grep "event tase1_" scripts/main.zeek
```

## Production Deployment Checklist

- [ ] Parser tested on sample traffic
- [ ] Performance acceptable for traffic volume
- [ ] Logs rotating properly
- [ ] Alerts configured and tested
- [ ] Integration with SIEM working (if applicable)
- [ ] Thresholds tuned for environment
- [ ] Monitoring in place for parser itself
- [ ] Documentation reviewed by team
- [ ] Backup/recovery procedures documented
- [ ] Change control approval obtained

## Monitoring the Parser

### Check Parser Health

```bash
# Verify parser is processing traffic
tail -f /usr/local/zeek/logs/current/tase1.log

# Check for errors in stderr
tail -f /usr/local/zeek/logs/current/stderr.log | grep -i tase
```

### Log Analysis

```bash
# Count connections by source
cat tase1.log | zeek-cut id.orig_h | sort | uniq -c | sort -rn

# Find all WRITE operations
grep "WRITE" tase1.log

# Show error events
grep "ERROR" tase1.log
```

## Next Steps After Installation

1. **Configure Monitoring**: Set up appropriate thresholds
2. **Integrate Alerting**: Connect to your alerting system
3. **Baseline Normal**: Establish normal traffic patterns
4. **Create Dashboards**: Visualize TASE.1 metrics
5. **Document Procedures**: Create runbooks for your team
6. **Schedule Reviews**: Regular analysis of logs

## Getting Help

If you encounter issues:

1. Check this guide's troubleshooting section
2. Review README.md for detailed documentation
3. Enable debug output for diagnostics
4. Check Zeek and Spicy documentation
5. Review generated logs for clues
6. Open an issue with details about your environment

## Success Indicators

You'll know the installation is successful when:

✓ `zeek -NN` shows the TASE1 analyzer
✓ Test scripts run without errors
✓ `tase1.log` is created and populated
✓ Events are logged correctly
✓ No parsing errors in output
✓ Can analyze real TASE.1 traffic
✓ Alerts trigger appropriately

---

**Congratulations!** Your TASE.1 parser is now installed and ready for use in monitoring power grid communications.
