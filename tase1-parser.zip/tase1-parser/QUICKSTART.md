# TASE.1 Parser Quick Start Guide

## Installation in 5 Minutes

### Option 1: Using Zeek Package Manager (Recommended)

```bash
# Install the parser
zkg install /path/to/tase1-parser

# Verify installation
zeek -NN | grep TASE1
```

### Option 2: Manual Installation

```bash
cd tase1-parser
./configure --zeek-dist=/opt/zeek
cd build
make -j4
sudo make install
```

## Basic Usage

### Monitor Live Traffic

```bash
# Monitor interface for TASE.1 traffic
sudo zeek -i eth0 tase1-parser

# Check the logs
tail -f tase1.log
```

### Analyze PCAP Files

```bash
# Analyze captured traffic
zeek -r tase1_traffic.pcap tase1-parser

# View results
cat tase1.log
```

## Common Use Cases

### 1. Detect Write Operations

```bash
# Run with alerting on WRITE operations
zeek -r traffic.pcap tase1-parser scripts/examples/advanced_analysis.zeek
```

### 2. Monitor Specific Connections

Add to `local.zeek`:
```zeek
@load tase1-parser

event tase1_connection_request(c: connection, src_ref: count, dst_ref: count, class_option: count) {
    if ( c$id$orig_h == 192.168.1.10 ) {
        print fmt("Connection from monitored host: %s", c$id$orig_h);
    }
}
```

### 3. Track All MMS Services

```bash
# Enable detailed logging
zeek -r traffic.pcap tase1-parser 'Log::default_rotation_interval=1hr'
```

## Viewing Logs

TASE.1 logs are written to `tase1.log`:

```bash
# View recent activity
tail -f tase1.log

# Search for specific events
grep "WRITE" tase1.log

# Count event types
cut -f9 tase1.log | sort | uniq -c
```

## Troubleshooting

### No logs generated?

1. Check if port 102 traffic exists:
   ```bash
   tcpdump -i eth0 'tcp port 102' -c 10
   ```

2. Verify parser is loaded:
   ```bash
   zeek -NN | grep -i tase
   ```

3. Enable debug mode:
   ```bash
   zeek -r test.pcap tase1-parser Spicy::enable_print=T
   ```

### Parser errors?

Check Zeek's stderr output:
```bash
zeek -r test.pcap tase1-parser 2>&1 | less
```

## Next Steps

- Read the full [README.md](README.md) for detailed documentation
- Explore [scripts/examples/](scripts/examples/) for advanced use cases
- Customize thresholds in your `local.zeek`
- Integrate with your SIEM or alerting system

## Support

- Documentation: `README.md`
- Issues: Open a GitHub issue
- Questions: security@example.com
