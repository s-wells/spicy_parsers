# Changelog

All notable changes to the TASE.1 Parser project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2024-01-08

### Added
- Initial release of TASE.1 protocol parser
- Full TPKT/ISO-TSAP layer parsing (RFC 1006)
- MMS protocol support (ISO 9506)
- ASN.1 BER decoding for data types
- Connection lifecycle tracking (CR, CC, DR, DC)
- MMS service type identification (READ, WRITE, etc.)
- Comprehensive logging to tase1.log
- Security monitoring with Zeek notices:
  - Unauthorized_Connection
  - Suspicious_Service_Request
  - Excessive_Errors
  - Abnormal_Disconnect
- Configurable thresholds for anomaly detection
- Connection state management
- Support for all major TPDU types
- Example scripts for advanced analysis
- Complete documentation (README, QUICKSTART)
- Zeek package manager support
- CMake build system
- Test suite framework

### Features
- Parses 10+ MMS service types
- Tracks invoke IDs for request/response correlation
- Monitors error rates per connection
- Detects high request rate anomalies
- Identifies WRITE operations for alerting
- Connection pair tracking
- Bidirectional traffic analysis

### Documentation
- Comprehensive README with protocol details
- Quick start guide for new users
- Advanced analysis examples
- Architecture documentation
- Troubleshooting guide
- Installation instructions

### Technical Details
- Spicy grammar: ~350 lines
- Zeek script: ~400 lines
- Full protocol stack implementation
- Production-ready error handling
- Optimized for ICS/SCADA environments

## [Unreleased]

### Planned
- Enhanced ASN.1 BER decoding for complex structures
- TASE.1 data object type parsing
- TLS/SSL support for encrypted traffic
- Performance optimizations for high-volume environments
- Integration with Zeek's intel framework
- Baseline profiling for normal operations
- Machine learning anomaly detection
- Export to SIEM formats
- Grafana dashboard templates

### Under Consideration
- Prometheus metrics export
- Real-time alerting integration
- Protocol fuzzing test suite
- Wireshark dissector compatibility
- IEC 61850 correlation
- Historical analysis tools

---

## Version History

- **1.0.0** (2024-01-08): Initial stable release
