# TASE.1 Protocol Parser for Zeek

A comprehensive Zeek protocol analyzer for TASE.1 (Telecontrol Application Service Element 1), also known as ICCP (Inter-Control Center Communications Protocol), implemented using Spicy.

## Overview

TASE.1/ICCP is a critical protocol used in power grid SCADA systems for inter-utility communications. This parser provides deep packet inspection capabilities for monitoring and analyzing TASE.1 traffic in operational technology (OT) networks.

### Protocol Stack

```
┌─────────────────────────┐
│   TASE.1 Data Objects   │  Application Layer
├─────────────────────────┤
│   MMS (ISO 9506)        │  Presentation Layer
├─────────────────────────┤
│   ISO-TSAP (RFC 1006)   │  Session/Transport Layer
├─────────────────────────┤
│   TPKT (RFC 1006)       │  Framing Layer
├─────────────────────────┤
│   TCP (Port 102)        │  Transport Layer
└─────────────────────────┘
```

## Features

### Protocol Parsing
- **TPKT Framing**: RFC 1006 framing layer
- **ISO-TSAP**: Transport Protocol Data Units (TPDU)
  - Connection Request (CR)
  - Connection Confirm (CC)
  - Disconnect Request (DR)
  - Disconnect Confirm (DC)
  - Data Transfer (DT)
- **MMS Protocol**: Manufacturing Message Specification
  - Confirmed Request/Response
  - Unconfirmed Services
  - Initiate Request/Response
  - Error and Reject PDUs
- **ASN.1 BER Decoding**: Basic Encoding Rules for data types

### Security Monitoring
- Connection establishment tracking
- Service request monitoring (READ, WRITE, GET operations)
- Error rate analysis
- Anomaly detection for:
  - Unauthorized connections
  - Suspicious write operations
  - Excessive errors
  - Abnormal disconnects
  - High request rates

### Logging
- Comprehensive TASE.1 activity logging
- Connection state tracking
- MMS service type identification
- Invoke ID correlation
- Timestamped event records

## Installation

### Prerequisites
- Zeek 5.0 or later
- Spicy 1.6 or later
- CMake 3.15 or later
- C++17 compatible compiler

### Building from Source

```bash
# Clone or download the parser
cd tase1-parser

# Configure
./configure --zeek-dist=/path/to/zeek/source

# Build
cd build
make -j4

# Install
sudo make install
```

### Using Zeek Package Manager

```bash
# Install directly from repository
zkg install /path/to/tase1-parser

# Or if published to packages.zeek.org
zkg install tase1-parser
```

## Usage

### Basic Usage

```bash
# Load the parser with Zeek
zeek -i eth0 tase1-parser

# Analyze PCAP file
zeek -r tase1_traffic.pcap tase1-parser
```

### Configuration

Add to your `local.zeek`:

```zeek
@load packages/tase1-parser

# Configure thresholds
redef TASE1::error_threshold = 5;
redef TASE1::request_rate_threshold = 50;
```

### Custom Analysis Script

```zeek
@load packages/tase1-parser

event tase1_confirmed_request(c: connection, invoke_id: count, service_type: count) {
    # Custom logic for specific MMS services
    if ( service_type == 1 ) {  # WRITE operation
        print fmt("WRITE detected from %s to %s", c$id$orig_h, c$id$resp_h);
    }
}

event tase1_connection_request(c: connection, src_ref: count, dst_ref: count, class_option: count) {
    # Track new TASE.1 connections
    print fmt("New TASE.1 connection: %s -> %s", c$id$orig_h, c$id$resp_h);
}
```

## Log Format

The parser creates a `tase1.log` file with the following fields:

| Field | Type | Description |
|-------|------|-------------|
| ts | time | Timestamp of the event |
| uid | string | Connection unique identifier |
| id | conn_id | Connection 4-tuple |
| src_ref | count | Source endpoint reference |
| dst_ref | count | Destination endpoint reference |
| class_option | count | Connection class/option |
| invoke_id | count | MMS invoke identifier |
| service_type | string | MMS service name |
| event_type | string | Event category |
| details | string | Additional information |

### Example Log Entry

```
1704067200.000000  CaB8Fk1234567890  192.168.1.10  41234  10.0.0.20  102  tcp  1024  2048  0  12345  READ  CONFIRMED_REQUEST  -
```

## MMS Service Types

The parser recognizes the following MMS service types:

| Code | Service | Description |
|------|---------|-------------|
| 0 | READ | Read variable values |
| 1 | WRITE | Write variable values |
| 2 | GET_NAME_LIST | Retrieve object names |
| 3 | IDENTIFY | Identify server capabilities |
| 4 | GET_CAPABILITY_LIST | Get server capabilities |
| 5 | DEFINE_NAMED_VARIABLE | Define new variable |
| 6 | DELETE_NAMED_VARIABLE | Delete variable |
| 7 | GET_VARIABLE_ACCESS | Get variable access attributes |
| 8 | DEFINE_DATA_SET | Define data set |
| 9 | DELETE_DATA_SET | Delete data set |
| 10 | GET_DATA_SET_DIRECTORY | Get data set directory |

## Security Notices

The parser generates Zeek notices for suspicious activities:

### `TASE1::Unauthorized_Connection`
Raised when an unauthorized connection attempt is detected.

### `TASE1::Suspicious_Service_Request`
Raised for suspicious MMS service requests, including:
- WRITE operations (potentially modifying critical data)
- High request rates exceeding threshold

### `TASE1::Excessive_Errors`
Raised when error count exceeds the configured threshold, which may indicate:
- Configuration problems
- Protocol violations
- Potential attack attempts

### `TASE1::Abnormal_Disconnect`
Raised for disconnections with non-zero reason codes, indicating:
- Protocol errors
- Forced disconnections
- Connection failures

## Architecture

### File Structure

```
tase1-parser/
├── src/
│   ├── tase1.spicy       # Spicy grammar definition
│   ├── tase1.evt         # Zeek event definitions
│   └── tase1.analyzer    # Analyzer configuration
├── scripts/
│   └── main.zeek         # Main Zeek analysis script
├── cmake/
│   └── FindSpicy.cmake   # CMake module (if needed)
├── tests/
│   └── (test files)
├── CMakeLists.txt        # Build configuration
├── configure             # Configuration script
├── zkg.meta              # Package metadata
└── README.md             # This file
```

### Protocol Layers

1. **TPKT Layer**: Handles RFC 1006 framing
2. **TPDU Layer**: Processes ISO transport PDUs
3. **MMS Layer**: Parses Manufacturing Message Specification
4. **TASE.1 Layer**: Handles TASE.1-specific data objects

## Development

### Testing

```bash
# Run with test PCAP
zeek -r tests/tase1_sample.pcap scripts/main.zeek

# Enable debug output
zeek -r test.pcap scripts/main.zeek Spicy::enable_print=T
```

### Debugging Spicy Grammar

```bash
# Compile Spicy grammar standalone
spicyc src/tase1.spicy

# Parse test data
echo -n -e '\x03\x00\x00\x16\x11\xf0\x00\x00\x00\x01...' | spicy-driver src/tase1.spicy
```

### Adding New Features

1. **New MMS Service**: Add service type to `mms_service_names` table
2. **New Event**: Define in `tase1.evt` and add handler in `main.zeek`
3. **New Data Type**: Add to Spicy grammar in `tase1.spicy`

## Performance Considerations

- The parser handles ASN.1 BER encoding which can be complex
- Large data transfers may require tuning
- Consider filtering to specific connections if processing high volumes

## Known Limitations

1. **ASN.1 Decoding**: Basic BER decoding implemented; complex structures may need enhancement
2. **Data Objects**: TASE.1-specific data objects are partially parsed
3. **Encryption**: Does not handle TLS-wrapped TASE.1 traffic
4. **Fragmentation**: Large PDUs spanning multiple TCP segments may need additional handling

## Troubleshooting

### Parser Not Loading

```bash
# Verify installation
zeek -NN | grep TASE1

# Check for errors
zeek -r test.pcap tase1-parser 2>&1 | grep -i error
```

### No Events Generated

1. Verify TCP port 102 traffic exists
2. Check TPKT version byte (should be 0x03)
3. Enable Spicy debug output

### Build Errors

```bash
# Clean build
rm -rf build
./configure --zeek-dist=/path/to/zeek
cd build && make clean && make
```

## References

- **RFC 2357**: TASE.1 Protocol Specification
- **RFC 1006**: ISO Transport Services on TCP/IP
- **ISO 9506**: Manufacturing Message Specification (MMS)
- **IEC 60870-6**: TASE.1/ICCP Standard

## Contributing

Contributions are welcome! Please:

1. Fork the repository
2. Create a feature branch
3. Add tests for new functionality
4. Submit a pull request

## License

[Insert your license here]

## Support

For issues, questions, or contributions:
- Open an issue on GitHub
- Contact: security@example.com

## Acknowledgments

Built using the Spicy parser framework and Zeek network security monitor.

---

**Security Note**: This parser is designed for monitoring legitimate TASE.1/ICCP communications in authorized industrial control system environments. Ensure proper authorization before monitoring any network traffic.
