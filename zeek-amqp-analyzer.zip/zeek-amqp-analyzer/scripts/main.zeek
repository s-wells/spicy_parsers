##! AMQP Protocol Analyzer

module AMQP;

export {
    redef enum Log::ID += { LOG };

    type Info: record {
        ts: time &log;
        uid: string &log;
        id: conn_id &log;
        
        protocol_id: count &log &optional;
        version_major: count &log &optional;
        version_minor: count &log &optional;
        version_revision: count &log &optional;
        
        channel_max: count &log &optional;
        frame_max: count &log &optional;
        heartbeat: count &log &optional;
        
        total_frames: count &log &default=0;
        method_frames: count &log &default=0;
        header_frames: count &log &default=0;
        body_frames: count &log &default=0;
        
        queues_declared: count &log &default=0;
        queues_deleted: count &log &default=0;
        exchanges_declared: count &log &default=0;
        exchanges_deleted: count &log &default=0;
        
        messages_published: count &log &default=0;
        messages_delivered: count &log &default=0;
        messages_acked: count &log &default=0;
        messages_rejected: count &log &default=0;
        
        connection_closed: bool &log &default=F;
        close_reply_code: count &log &optional;
    };
}

redef record connection += {
    amqp: Info &optional;
};

event zeek_init() &priority=5 {
    Log::create_stream(AMQP::LOG, [$columns=Info, $path="amqp"]);
}

function set_session(c: connection) {
    if ( ! c?$amqp ) {
        c$amqp = [$ts=network_time(), $uid=c$uid, $id=c$id];
    }
}

event amqp_protocol_header(c: connection, is_orig: bool, protocol_id: count,
                           version_major: count, version_minor: count,
                           version_revision: count) {
    set_session(c);
    
    c$amqp$protocol_id = protocol_id;
    c$amqp$version_major = version_major;
    c$amqp$version_minor = version_minor;
    c$amqp$version_revision = version_revision;
}

event amqp_frame(c: connection, is_orig: bool, frame_type: count,
                 channel: count, payload_size: count) {
    set_session(c);
    
    c$amqp$total_frames += 1;
    
    if ( frame_type == 1 )
        c$amqp$method_frames += 1;
    else if ( frame_type == 2 )
        c$amqp$header_frames += 1;
    else if ( frame_type == 3 )
        c$amqp$body_frames += 1;
}

event amqp_connection_tune_ok(c: connection, is_orig: bool, channel_max: count,
                              frame_max: count, heartbeat: count) {
    set_session(c);
    
    c$amqp$channel_max = channel_max;
    c$amqp$frame_max = frame_max;
    c$amqp$heartbeat = heartbeat;
}

event amqp_connection_close(c: connection, is_orig: bool, reply_code: count) {
    set_session(c);
    
    c$amqp$connection_closed = T;
    c$amqp$close_reply_code = reply_code;
}

event amqp_queue_declare(c: connection, is_orig: bool) {
    set_session(c);
    c$amqp$queues_declared += 1;
}

event amqp_queue_delete(c: connection, is_orig: bool) {
    set_session(c);
    c$amqp$queues_deleted += 1;
}

event amqp_exchange_declare(c: connection, is_orig: bool) {
    set_session(c);
    c$amqp$exchanges_declared += 1;
}

event amqp_exchange_delete(c: connection, is_orig: bool) {
    set_session(c);
    c$amqp$exchanges_deleted += 1;
}

event amqp_basic_publish(c: connection, is_orig: bool) {
    set_session(c);
    c$amqp$messages_published += 1;
}

event amqp_basic_deliver(c: connection, is_orig: bool,
                         delivery_tag: count, redelivered: count) {
    set_session(c);
    c$amqp$messages_delivered += 1;
}

event amqp_basic_ack(c: connection, is_orig: bool,
                     delivery_tag: count, multiple: count) {
    set_session(c);
    c$amqp$messages_acked += 1;
}

event amqp_basic_reject(c: connection, is_orig: bool,
                        delivery_tag: count, requeue: count) {
    set_session(c);
    c$amqp$messages_rejected += 1;
}

event amqp_basic_nack(c: connection, is_orig: bool, delivery_tag: count) {
    set_session(c);
    c$amqp$messages_rejected += 1;
}

event connection_state_remove(c: connection) {
    if ( c?$amqp )
        Log::write(AMQP::LOG, c$amqp);
}
