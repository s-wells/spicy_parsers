signature dpd_amqp_client {
    ip-proto == tcp
    payload /AMQP/
    tcp-state originator
    enable "spicy_AMQP"
}

signature dpd_amqp_server {
    ip-proto == tcp
    payload /AMQP/
    tcp-state responder
    enable "spicy_AMQP"
}
