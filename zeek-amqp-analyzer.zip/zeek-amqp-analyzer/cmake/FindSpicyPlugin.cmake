# Placeholder for FindSpicyPlugin.cmake if needed
# Usually this is provided by Zeek's installation
