# spicy-iccp Architecture

This document describes the design and implementation of the spicy-iccp analyzer.

## Overview

The spicy-iccp analyzer provides deep packet inspection for ICCP/TASE.2 protocol traffic used in power grid control centers. It parses the complete protocol stack from TPKT through COTP and MMS to extract ICCP application-layer data.

## Protocol Stack

### Layer Architecture

```
┌───────────────────────────────────────────┐
│  ICCP/TASE.2 Application Layer            │
│  - Transfer Sets, Data Sets               │
│  - Control Operations, Information Msgs   │
├───────────────────────────────────────────┤
│  MMS Layer (ISO 9506)                     │
│  - Initiate/Conclude Sessions             │
│  - Read/Write/GetNameList/Identify        │
│  - Variable Access, Object Names          │
├───────────────────────────────────────────┤
│  COTP Layer (ISO 8073)                    │
│  - Connection Management (CR/CC/DR/DC)    │
│  - Data Transfer (DT) with EOT            │
│  - Reference Tracking                     │
├───────────────────────────────────────────┤
│  TPKT Layer (RFC 1006)                    │
│  - Version: 3                             │
│  - Length Framing                         │
├───────────────────────────────────────────┤
│  TCP Port 102                             │
└───────────────────────────────────────────┘
```

## File Structure

### Spicy Grammar (`analyzer/iccp.spicy`)

The grammar file defines the protocol structure using Spicy's parser generator language:

#### TPKT Layer
- `TPKTHeader`: Version (3), Reserved, Length
- Validates minimum packet size
- Provides length for subsequent layers

#### COTP Layer
- `COTPConnectionRequest/Confirm`: Connection establishment
- `COTPDisconnectRequest`: Connection teardown
- `COTPData`: Data transfer with TPDU numbering and EOT flag
- Supports all COTP PDU types (CR, CC, DR, DC, DT)

#### MMS Layer

**Session Management:**
- `MMSInitiateRequest/Response`: Session establishment with parameter negotiation
  - Local detail, max services outstanding
  - Data structure nesting level
  - Version number, parameter CBB
  - Supported services bitmap
- `MMSConcludeRequest/Response`: Session termination

**Service PDUs:**
- `MMSConfirmedRequestPDU/ResponsePDU`: Request/response pairs with invoke IDs
- Service-specific parsers for:
  - Identify: Device identification
  - GetNameList: Object enumeration
  - Read: Data value retrieval
  - Write: Data value modification
  - GetVariableAccessAttributes: Type information

**Object Naming:**
- `MMSObjectName`: Three naming schemes
  - VMD-specific: Virtual Manufacturing Device scope
  - Domain-specific: Domain/Item hierarchy
  - AA-specific: Application Association scope

### Event Definitions (`analyzer/iccp.evt`)

Maps Spicy parser units to Zeek events:

```spicy
on MMSInitiateRequest -> event iccp::mms_initiate_request(...);
on MMSReadRequest -> event iccp::mms_read_request(...);
```

Events are generated when parser units complete successfully, providing:
- Connection context (`$conn`)
- Parsed field values
- Byte strings for complex data

### Zeek Script (`scripts/main.zeek`)

Implements protocol logic and logging:

#### Connection State Management
```zeek
redef record connection += {
    iccp: Info &optional;
};
```

Each connection maintains:
- Session parameters
- Device identification
- Operation statistics
- Current object access

#### Event Handlers

**Session Events:**
- Track MMS session establishment and parameters
- Monitor connection lifecycle
- Extract negotiated capabilities

**Operation Events:**
- Log all read/write operations
- Track invoke IDs for request/response correlation
- Extract object names and values
- Accumulate operation statistics

**Device Identification:**
- Parse vendor, model, revision strings
- Build device inventory
- Detect unknown devices

#### Logging

The `iccp.log` file captures:
- All protocol operations
- Session parameters
- Device information
- Object access patterns
- Operation statistics per connection

### Security Monitoring (`scripts/security.zeek`)

Provides security analysis capabilities:

#### Threat Detection

**Unauthorized Access:**
- Validates source IP against allowed controllers
- Detects writes from unexpected sources
- Monitors connections to unauthorized servers

**Anomaly Detection:**
- Excessive read/write operations
- Rapid successive writes
- Abnormal traffic patterns
- Unexpected session establishments

**Critical Asset Protection:**
- Pattern matching on object names
- Alerts on breaker/switch control
- Monitors setpoint modifications

#### Device Tracking

- Maintains inventory of connected devices
- Detects unknown/unexpected vendors
- Tracks device firmware versions
- Periodic inventory reporting

## Data Flow

### Packet Processing Pipeline

```
1. TCP Stream Reassembly
   ↓
2. TPKT Frame Extraction
   │  - Validate version (3)
   │  - Extract length
   │  - Frame boundary detection
   ↓
3. COTP Layer Parsing
   │  - Connection management
   │  - Data segmentation handling
   │  - EOT tracking
   ↓
4. MMS PDU Parsing
   │  - Session management
   │  - Service requests/responses
   │  - Invoke ID correlation
   ↓
5. Object Name Resolution
   │  - VMD/Domain/AA parsing
   │  - Name string extraction
   ↓
6. Data Value Extraction
   │  - Type identification
   │  - Value parsing
   │  - Hex encoding
   ↓
7. Zeek Event Generation
   │  - Event dispatch
   │  - Connection context
   ↓
8. Log Writing
   └─> iccp.log
```

### Event Flow

```
Parser Unit Completion
  ↓
Spicy Event (.evt file)
  ↓
Zeek Event Handler (main.zeek)
  ↓
Connection State Update
  ↓
Conditional Logging
  ↓
Security Analysis (security.zeek)
```

## Design Decisions

### Stateful vs Stateless Parsing

**Stateful Components:**
- Connection state tracking (session parameters, statistics)
- Invoke ID correlation (future enhancement)
- Device inventory maintenance

**Stateless Components:**
- Protocol parsing (each packet independent)
- Event generation (no cross-packet dependencies)

### Logging Strategy

**Log on Response, Not Request:**
- Write logs when responses complete
- Ensures invoke ID correlation
- Captures complete operation cycle

**Exception:** Session events log immediately for visibility

### Error Handling

**Graceful Degradation:**
- Continue parsing on non-critical errors
- Use `switch` with defaults for unknown values
- Reject protocol only on fundamental violations

**Validation:**
- TPKT version check (must be 3)
- Length validation (prevent under/overflow)
- Tag validation in MMS (ensures correct PDU type)

### Performance Considerations

**Efficient Parsing:**
- Minimal lookahead (only where necessary)
- Direct byte access for simple fields
- Switch-based dispatching for PDU types

**Memory Management:**
- Create connection state lazily
- Expire device inventory after 24h
- Use &create_expire for temporary tables

## Extension Points

### Adding New MMS Services

1. Add service type to `MMSServiceType` enum
2. Create parser unit in `iccp.spicy`
3. Add service case in `MMSConfirmedServiceRequest`
4. Define event in `iccp.evt`
5. Implement handler in `main.zeek`
6. Update log record if needed

### Adding ICCP/TASE.2 Features

ICCP builds on MMS but adds specific data structures:

1. Define TASE.2 structures in `iccp.spicy`
2. Parse within MMS data values
3. Create TASE.2-specific events
4. Log transfer sets, bilateral tables, etc.

### Security Detection Rules

Add to `security.zeek`:

1. Define new Notice::Type
2. Implement detection logic in event handler
3. Use SumStats for rate-based detection
4. Configure thresholds as `&redef` constants

## Testing Strategy

### Unit Tests
- Individual protocol layer parsing
- Edge cases (minimum/maximum sizes)
- Error conditions

### Integration Tests
- Complete protocol stack
- Real-world traffic patterns
- Security detection validation

### Performance Tests
- High packet rates
- Many concurrent connections
- Memory usage profiling

## Known Limitations

1. **Invoke ID Correlation**: Currently not implemented - each request/response logged separately
2. **TASE.2 Semantics**: MMS layer only, not full TASE.2 application objects
3. **Segmentation**: COTP segmentation tracking not fully implemented
4. **State Management**: Limited cross-packet state (intentional for simplicity)

## Future Enhancements

1. **Complete TASE.2 Support**:
   - Transfer set parsing
   - Bilateral table extraction
   - Data set structures

2. **Enhanced Correlation**:
   - Request/response pairing by invoke ID
   - Multi-packet operation tracking

3. **Performance Optimization**:
   - Reduce memory allocations
   - Optimize string conversions
   - Profile hot paths

4. **Extended Security**:
   - Machine learning anomaly detection
   - Behavioral baselining
   - Threat intelligence integration

## References

- **IEC 60870-6-503**: TASE.2 standard
- **ISO 9506**: MMS specification
- **ISO 8073**: COTP specification
- **RFC 1006**: TPKT specification
- **Spicy Documentation**: https://docs.zeek.org/projects/spicy
- **Zeek Plugin Development**: https://docs.zeek.org/projects/spicy/en/latest/
