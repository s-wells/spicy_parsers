# spicy-iccp Quick Start Guide

## Installation

### Using Zeek Package Manager
```bash
cd spicy-iccp
zkg install .
```

### Manual Build
```bash
./configure --zeek-dist=$(zeek-config --zeek_dist)
cd build
make -j4
sudo make install
```

## Basic Usage

### Monitor ICCP Traffic
```bash
# From PCAP
zeek -Cr traffic.pcap spicy-iccp

# Live capture
zeek -i eth0 spicy-iccp
```

### Enable Security Monitoring
```bash
zeek -Cr traffic.pcap spicy-iccp spicy-iccp/security
```

### Custom Configuration
```zeek
# local.zeek
@load spicy-iccp

# Add custom ports
redef ICCP::ports += { 2404/tcp };

# Define authorized controllers
redef ICCPSecurity::authorized_controllers = {
    192.168.1.10,
    192.168.1.11,
};

# Define authorized servers
redef ICCPSecurity::authorized_servers = {
    192.168.1.20,
};
```

## Verification

### Check Analyzer is Loaded
```bash
zeek -NN | grep ICCP
```

Expected output:
```
[Analyzer] spicy_ICCP (ANALYZER_ICCP, enabled)
```

### Test with Sample Traffic
```bash
# Run example script
zeek -Cr test.pcap scripts/example.zeek
```

## Log Files

### iccp.log
Main protocol log with all operations:
- Session establishment
- Read/Write operations  
- Device identification
- Object access
- Statistics

### notice.log (with security.zeek)
Security alerts:
- Unauthorized writes
- Excessive operations
- Unknown devices
- Critical object access

## Common Issues

### Analyzer Not Loading
```bash
# Check Spicy installation
spicyz --version

# Check plugin directory
ls $(zeek-config --plugin_dir)

# Rebuild
rm -rf build && ./configure && cd build && make
```

### No Logs Generated
```bash
# Enable debug
zeek -Cr traffic.pcap spicy-iccp Spicy::enable_print=T

# Check for ICCP traffic
tcpdump -r traffic.pcap 'tcp port 102'
```

### Protocol Not Detected
```bash
# Force analyzer
zeek -Cr traffic.pcap -e '
event connection_established(c: connection) {
    if ( c$id$resp_p == 102/tcp )
        Analyzer::schedule_analyzer(c, Analyzer::ANALYZER_ICCP);
}'
```

## Next Steps

1. Read `README.md` for comprehensive documentation
2. Review `ARCHITECTURE.md` for design details
3. Customize `scripts/security.zeek` for your environment
4. Check `scripts/example.zeek` for usage patterns
