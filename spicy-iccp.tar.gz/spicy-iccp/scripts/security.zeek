##! ICCP Security Monitoring
##! Detects suspicious activity in ICCP/TASE.2 traffic
##!
##! This script provides security monitoring for ICCP traffic including:
##! - Unauthorized write operations
##! - Excessive read requests
##! - Unknown or unexpected devices
##! - Suspicious data access patterns
##! - Session anomalies

@load base/frameworks/notice
@load base/frameworks/sumstats
@load spicy-iccp

module ICCPSecurity;

export {
    redef enum Notice::Type += {
        ## Unauthorized write operation detected
        ICCP_Unauthorized_Write,
        
        ## High rate of read operations detected
        ICCP_Excessive_Reads,
        
        ## Unknown or unexpected device identified
        ICCP_Unknown_Device,
        
        ## Suspicious object access detected
        ICCP_Suspicious_Access,
        
        ## Unexpected session establishment
        ICCP_Unexpected_Session,
        
        ## Write to critical object
        ICCP_Critical_Write,
        
        ## Session from unauthorized source
        ICCP_Unauthorized_Source,
        
        ## Abnormal data transfer pattern
        ICCP_Abnormal_Pattern,
    };
    
    ## Set of authorized controller IP addresses
    global authorized_controllers: set[addr] = {
        192.168.1.10,
        192.168.1.11,
        10.0.0.50,
    } &redef;
    
    ## Set of authorized SCADA server IP addresses
    global authorized_servers: set[addr] = {
        192.168.1.20,
        10.0.0.100,
    } &redef;
    
    ## Known/expected device vendors
    global known_vendors: set[string] = {
        "ABB",
        "Siemens",
        "GE",
        "Schneider Electric",
        "Areva",
        "Alstom",
    } &redef;
    
    ## Critical object name patterns (hex or string)
    global critical_objects: pattern = /BREAKER|SWITCH|TRIP|CLOSE|MW_SETPOINT|VOLTAGE_CTRL/ &redef;
    
    ## Threshold for read operations per connection
    const read_threshold: count = 500 &redef;
    
    ## Threshold for write operations per connection
    const write_threshold: count = 100 &redef;
    
    ## Threshold for rapid successive writes (per minute)
    const rapid_write_threshold: count = 50 &redef;
    
    ## Monitor writes to critical objects
    const monitor_critical_writes: bool = T &redef;
}

# Track write operations for rate limiting
global write_tracker: table[addr] of count &create_expire=1min &default=0;

# Track identified devices
global device_inventory: table[addr] of vector of string &create_expire=24hr;

############################################################################
# Session Monitoring
############################################################################

event ICCP::mms_initiate_request(c: connection, local_detail: count,
                                max_serv_out_calling: count,
                                max_serv_out_called: count,
                                nesting_level: count, version: count,
                                param_cbb: string, services: string) {
    # Check if session initiation is from authorized source
    if ( c$id$orig_h !in authorized_controllers &&
         c$id$orig_h !in authorized_servers ) {
        NOTICE([$note=ICCP_Unauthorized_Source,
                $conn=c,
                $msg=fmt("ICCP session initiated from unauthorized source: %s",
                        c$id$orig_h),
                $identifier=cat(c$id$orig_h, c$id$resp_h)]);
    }
    
    # Check if connecting to authorized server
    if ( c$id$resp_h !in authorized_servers &&
         c$id$resp_h !in authorized_controllers ) {
        NOTICE([$note=ICCP_Unexpected_Session,
                $conn=c,
                $msg=fmt("ICCP session to unexpected server: %s", c$id$resp_h),
                $identifier=cat(c$id$orig_h, c$id$resp_h)]);
    }
}

############################################################################
# Device Identification Monitoring
############################################################################

event ICCP::mms_identify_response(c: connection, invoke_id: string,
                                 vendor: string, model: string,
                                 revision: string) {
    local vendor_str = "";
    local model_str = "";
    local revision_str = "";
    
    # Convert byte strings to readable strings
    for ( i in vendor ) {
        if ( vendor[i] >= 0x20 && vendor[i] <= 0x7E )
            vendor_str += vendor[i];
    }
    
    for ( i in model ) {
        if ( model[i] >= 0x20 && model[i] <= 0x7E )
            model_str += model[i];
    }
    
    for ( i in revision ) {
        if ( revision[i] >= 0x20 && revision[i] <= 0x7E )
            revision_str += revision[i];
    }
    
    # Check if vendor is known
    if ( vendor_str !in known_vendors && vendor_str != "" ) {
        NOTICE([$note=ICCP_Unknown_Device,
                $conn=c,
                $msg=fmt("Unknown ICCP device - Vendor: %s, Model: %s, Rev: %s",
                        vendor_str, model_str, revision_str),
                $identifier=cat(c$id$resp_h, vendor_str, model_str)]);
    }
    
    # Update device inventory
    if ( c$id$resp_h !in device_inventory )
        device_inventory[c$id$resp_h] = vector();
    
    device_inventory[c$id$resp_h] += fmt("%s %s %s", vendor_str, model_str,
                                         revision_str);
}

############################################################################
# Read Operation Monitoring
############################################################################

event ICCP::mms_read_request(c: connection, invoke_id: string,
                            spec_with_result: count, var_spec_tag: count) {
    # Check for excessive reads
    if ( c$iccp$read_count > read_threshold ) {
        NOTICE([$note=ICCP_Excessive_Reads,
                $conn=c,
                $msg=fmt("Excessive ICCP read operations: %d from %s",
                        c$iccp$read_count, c$id$orig_h),
                $identifier=cat(c$id$orig_h, "read_count"),
                $suppress_for=5min]);
    }
}

############################################################################
# Write Operation Monitoring
############################################################################

event ICCP::mms_write_request(c: connection, invoke_id: string,
                             var_spec_tag: count, data: string) {
    # Check if write is from authorized controller
    if ( c$id$orig_h !in authorized_controllers ) {
        NOTICE([$note=ICCP_Unauthorized_Write,
                $conn=c,
                $msg=fmt("Unauthorized ICCP write from %s to %s",
                        c$id$orig_h, c$id$resp_h),
                $identifier=cat(c$id$orig_h, c$id$resp_h, "write")]);
    }
    
    # Track write rate
    if ( c$id$orig_h in write_tracker )
        ++write_tracker[c$id$orig_h];
    else
        write_tracker[c$id$orig_h] = 1;
    
    # Check for rapid successive writes
    if ( write_tracker[c$id$orig_h] > rapid_write_threshold ) {
        NOTICE([$note=ICCP_Abnormal_Pattern,
                $conn=c,
                $msg=fmt("Rapid successive ICCP writes: %d in last minute from %s",
                        write_tracker[c$id$orig_h], c$id$orig_h),
                $identifier=cat(c$id$orig_h, "rapid_write"),
                $suppress_for=1min]);
    }
    
    # Check for excessive writes per connection
    if ( c$iccp$write_count > write_threshold ) {
        NOTICE([$note=ICCP_Abnormal_Pattern,
                $conn=c,
                $msg=fmt("Excessive ICCP write operations: %d from %s",
                        c$iccp$write_count, c$id$orig_h),
                $identifier=cat(c$id$orig_h, "write_count"),
                $suppress_for=5min]);
    }
}

############################################################################
# Object Access Monitoring
############################################################################

event ICCP::mms_object_vmd_specific(c: connection, name: string) {
    local hex_name = bytestring_to_hexstr(name);
    
    # Check for suspicious object names
    if ( monitor_critical_writes && critical_objects in hex_name ) {
        NOTICE([$note=ICCP_Critical_Write,
                $conn=c,
                $msg=fmt("Access to critical ICCP object: %s from %s",
                        hex_name, c$id$orig_h),
                $identifier=cat(c$id$orig_h, hex_name)]);
    }
}

event ICCP::mms_object_domain_specific(c: connection, domain_id: string,
                                      item_id: string) {
    local domain_str = "";
    local item_str = "";
    
    # Convert to readable strings
    for ( i in domain_id ) {
        if ( domain_id[i] >= 0x20 && domain_id[i] <= 0x7E )
            domain_str += domain_id[i];
    }
    
    for ( i in item_id ) {
        if ( item_id[i] >= 0x20 && item_id[i] <= 0x7E )
            item_str += item_id[i];
    }
    
    local full_name = fmt("%s/%s", domain_str, item_str);
    
    # Check for critical object access
    if ( monitor_critical_writes && critical_objects in full_name ) {
        NOTICE([$note=ICCP_Critical_Write,
                $conn=c,
                $msg=fmt("Access to critical ICCP object: %s from %s",
                        full_name, c$id$orig_h),
                $identifier=cat(c$id$orig_h, full_name)]);
    }
}

############################################################################
# Connection Statistics
############################################################################

event connection_state_remove(c: connection) {
    if ( ! c?$iccp )
        return;
    
    # Log connection summary for high-activity connections
    if ( c$iccp$read_count > 100 || c$iccp$write_count > 50 ) {
        Reporter::info(fmt("ICCP connection summary: %s -> %s, " +
                          "Reads: %d, Writes: %d, GetNameList: %d, Identify: %d",
                          c$id$orig_h, c$id$resp_h,
                          c$iccp$read_count, c$iccp$write_count,
                          c$iccp$get_name_list_count, c$iccp$identify_count));
    }
}

############################################################################
# Periodic Reporting
############################################################################

event zeek_init() {
    # Schedule periodic device inventory report
    schedule 1hr { report_device_inventory() };
}

event report_device_inventory() {
    if ( |device_inventory| == 0 ) {
        schedule 1hr { report_device_inventory() };
        return;
    }
    
    Reporter::info(fmt("ICCP Device Inventory (%d devices):", |device_inventory|));
    
    for ( ip in device_inventory ) {
        local devices = device_inventory[ip];
        if ( |devices| > 0 )
            Reporter::info(fmt("  %s: %s", ip, devices[|devices| - 1]));
    }
    
    # Schedule next report
    schedule 1hr { report_device_inventory() };
}
