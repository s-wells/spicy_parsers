@load ./main.zeek
