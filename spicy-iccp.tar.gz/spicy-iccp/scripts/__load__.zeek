##! Loader for ICCP protocol analyzer

@load ./main.zeek
