##! ICCP/TASE.2 Protocol Analyzer for Zeek
##! Provides comprehensive logging and analysis of ICCP traffic

module ICCP;

export {
    redef enum Log::ID += { LOG };
    
    ## ICCP connection record
    type Info: record {
        ## Timestamp
        ts: time &log;
        ## Unique connection identifier
        uid: string &log;
        ## Connection 4-tuple
        id: conn_id &log;
        ## Originator flag
        is_orig: bool &log;
        
        ## Service type
        service: string &log &optional;
        ## MMS invoke ID
        invoke_id: count &log &optional;
        
        ## MMS session parameters
        local_detail: count &log &optional;
        max_serv_out_calling: count &log &optional;
        max_serv_out_called: count &log &optional;
        nesting_level: count &log &optional;
        version_number: count &log &optional;
        
        ## Device identification
        vendor_name: string &log &optional;
        model_name: string &log &optional;
        revision: string &log &optional;
        
        ## Object access
        object_class: count &log &optional;
        object_name: string &log &optional;
        object_value: string &log &optional;
        
        ## Data values
        data_type: string &log &optional;
        data_value: string &log &optional;
        
        ## COTP info
        cotp_src_ref: count &log &optional;
        cotp_dst_ref: count &log &optional;
        cotp_class: count &log &optional;
        
        ## Statistics
        read_count: count &log &default=0;
        write_count: count &log &default=0;
        get_name_list_count: count &log &default=0;
        identify_count: count &log &default=0;
    };
    
    ## Event: COTP Connection Request
    global cotp_connection_request: event(c: connection, dst_ref: count,
                                         src_ref: count, class_option: count);
    
    ## Event: COTP Connection Confirm
    global cotp_connection_confirm: event(c: connection, dst_ref: count,
                                         src_ref: count, class_option: count);
    
    ## Event: COTP Disconnect Request
    global cotp_disconnect_request: event(c: connection, dst_ref: count,
                                         src_ref: count, reason: count);
    
    ## Event: COTP Data
    global cotp_data: event(c: connection, tpdu_nr: count, eot: bool);
    
    ## Event: MMS Initiate Request
    global mms_initiate_request: event(c: connection, local_detail: count,
                                      max_serv_out_calling: count,
                                      max_serv_out_called: count,
                                      nesting_level: count, version: count,
                                      param_cbb: string, services: string);
    
    ## Event: MMS Initiate Response
    global mms_initiate_response: event(c: connection, local_detail: count,
                                       max_serv_out_calling: count,
                                       max_serv_out_called: count,
                                       nesting_level: count, version: count,
                                       param_cbb: string, services: string);
    
    ## Event: MMS Conclude Request
    global mms_conclude_request: event(c: connection);
    
    ## Event: MMS Conclude Response
    global mms_conclude_response: event(c: connection);
    
    ## Event: MMS Identify Request
    global mms_identify_request: event(c: connection, invoke_id: string);
    
    ## Event: MMS Identify Response
    global mms_identify_response: event(c: connection, invoke_id: string,
                                       vendor: string, model: string,
                                       revision: string);
    
    ## Event: MMS Get Name List Request
    global mms_get_name_list_request: event(c: connection, invoke_id: string,
                                           object_class: count,
                                           object_scope: string);
    
    ## Event: MMS Get Name List Response
    global mms_get_name_list_response: event(c: connection, invoke_id: string,
                                            identifiers: string,
                                            more_follows: count);
    
    ## Event: MMS Read Request
    global mms_read_request: event(c: connection, invoke_id: string,
                                  spec_with_result: count, var_spec_tag: count);
    
    ## Event: MMS Read Response
    global mms_read_response: event(c: connection, invoke_id: string,
                                   var_access_spec: count, access_result: string);
    
    ## Event: MMS Write Request
    global mms_write_request: event(c: connection, invoke_id: string,
                                   var_spec_tag: count, data: string);
    
    ## Event: MMS Write Response
    global mms_write_response: event(c: connection, invoke_id: string,
                                    results: string);
    
    ## Event: MMS Get Variable Access Attributes Request
    global mms_get_variable_access_attributes_request: event(c: connection,
                                                            invoke_id: string);
    
    ## Event: MMS Get Variable Access Attributes Response
    global mms_get_variable_access_attributes_response: event(c: connection,
                                                             invoke_id: string,
                                                             deletable: count,
                                                             type_spec: string);
    
    ## Event: MMS Object VMD Specific
    global mms_object_vmd_specific: event(c: connection, name: string);
    
    ## Event: MMS Object Domain Specific
    global mms_object_domain_specific: event(c: connection, domain_id: string,
                                            item_id: string);
    
    ## Event: MMS Object AA Specific
    global mms_object_aa_specific: event(c: connection, name: string);
}

redef record connection += {
    iccp: Info &optional;
};

## Standard ICCP port (TPKT over TCP)
const ports = { 102/tcp };
redef likely_server_ports += { ports };

event zeek_init() &priority=5 {
    Log::create_stream(ICCP::LOG, [$columns=Info, $path="iccp"]);
    Analyzer::register_for_ports(Analyzer::ANALYZER_ICCP, ports);
}

function set_session(c: connection): Info {
    if ( ! c?$iccp ) {
        c$iccp = Info(
            $ts=network_time(),
            $uid=c$uid,
            $id=c$id,
            $is_orig=T
        );
    }
    return c$iccp;
}

function emit_log(c: connection) {
    if ( c?$iccp )
        Log::write(ICCP::LOG, c$iccp);
}

function bytes_to_hex(data: string): string {
    return bytestring_to_hexstr(data);
}

function bytes_to_count(data: string): count {
    return bytestring_to_count(data);
}

function bytes_to_string(data: string): string {
    local result = "";
    for ( i in data ) {
        local c = data[i];
        if ( c >= 0x20 && c <= 0x7E )
            result += c;
    }
    return result;
}

############################################################################
# COTP Event Handlers
############################################################################

event ICCP::cotp_connection_request(c: connection, dst_ref: count,
                                   src_ref: count, class_option: count) {
    local info = set_session(c);
    info$service = "COTP_CR";
    info$cotp_src_ref = src_ref;
    info$cotp_dst_ref = dst_ref;
    info$cotp_class = class_option;
}

event ICCP::cotp_connection_confirm(c: connection, dst_ref: count,
                                   src_ref: count, class_option: count) {
    local info = set_session(c);
    info$service = "COTP_CC";
    info$cotp_src_ref = src_ref;
    info$cotp_dst_ref = dst_ref;
    info$cotp_class = class_option;
    emit_log(c);
}

event ICCP::cotp_disconnect_request(c: connection, dst_ref: count,
                                   src_ref: count, reason: count) {
    local info = set_session(c);
    info$service = "COTP_DR";
    info$cotp_src_ref = src_ref;
    info$cotp_dst_ref = dst_ref;
    emit_log(c);
}

event ICCP::cotp_data(c: connection, tpdu_nr: count, eot: bool) {
    # Track COTP data segments if needed
}

############################################################################
# MMS Session Event Handlers
############################################################################

event ICCP::mms_initiate_request(c: connection, local_detail: count,
                                max_serv_out_calling: count,
                                max_serv_out_called: count,
                                nesting_level: count, version: count,
                                param_cbb: string, services: string) {
    local info = set_session(c);
    info$service = "MMS_INITIATE_REQ";
    info$local_detail = local_detail;
    info$max_serv_out_calling = max_serv_out_calling;
    info$max_serv_out_called = max_serv_out_called;
    info$nesting_level = nesting_level;
    info$version_number = version;
}

event ICCP::mms_initiate_response(c: connection, local_detail: count,
                                 max_serv_out_calling: count,
                                 max_serv_out_called: count,
                                 nesting_level: count, version: count,
                                 param_cbb: string, services: string) {
    local info = set_session(c);
    info$service = "MMS_INITIATE_RESP";
    info$local_detail = local_detail;
    info$max_serv_out_calling = max_serv_out_calling;
    info$max_serv_out_called = max_serv_out_called;
    info$nesting_level = nesting_level;
    info$version_number = version;
    emit_log(c);
}

event ICCP::mms_conclude_request(c: connection) {
    local info = set_session(c);
    info$service = "MMS_CONCLUDE_REQ";
    emit_log(c);
}

event ICCP::mms_conclude_response(c: connection) {
    local info = set_session(c);
    info$service = "MMS_CONCLUDE_RESP";
    emit_log(c);
}

############################################################################
# MMS Service Request Event Handlers
############################################################################

event ICCP::mms_identify_request(c: connection, invoke_id: string) {
    local info = set_session(c);
    info$service = "MMS_IDENTIFY_REQ";
    info$invoke_id = bytes_to_count(invoke_id);
    ++info$identify_count;
}

event ICCP::mms_identify_response(c: connection, invoke_id: string,
                                 vendor: string, model: string,
                                 revision: string) {
    local info = set_session(c);
    info$service = "MMS_IDENTIFY_RESP";
    info$invoke_id = bytes_to_count(invoke_id);
    info$vendor_name = bytes_to_string(vendor);
    info$model_name = bytes_to_string(model);
    info$revision = bytes_to_string(revision);
    emit_log(c);
}

event ICCP::mms_get_name_list_request(c: connection, invoke_id: string,
                                     object_class: count,
                                     object_scope: string) {
    local info = set_session(c);
    info$service = "MMS_GET_NAME_LIST_REQ";
    info$invoke_id = bytes_to_count(invoke_id);
    info$object_class = object_class;
    ++info$get_name_list_count;
}

event ICCP::mms_get_name_list_response(c: connection, invoke_id: string,
                                      identifiers: string,
                                      more_follows: count) {
    local info = set_session(c);
    info$service = "MMS_GET_NAME_LIST_RESP";
    info$invoke_id = bytes_to_count(invoke_id);
    info$object_value = bytes_to_hex(identifiers);
    emit_log(c);
}

event ICCP::mms_read_request(c: connection, invoke_id: string,
                            spec_with_result: count, var_spec_tag: count) {
    local info = set_session(c);
    info$service = "MMS_READ_REQ";
    info$invoke_id = bytes_to_count(invoke_id);
    ++info$read_count;
}

event ICCP::mms_read_response(c: connection, invoke_id: string,
                             var_access_spec: count, access_result: string) {
    local info = set_session(c);
    info$service = "MMS_READ_RESP";
    info$invoke_id = bytes_to_count(invoke_id);
    info$data_value = bytes_to_hex(access_result);
    emit_log(c);
}

event ICCP::mms_write_request(c: connection, invoke_id: string,
                             var_spec_tag: count, data: string) {
    local info = set_session(c);
    info$service = "MMS_WRITE_REQ";
    info$invoke_id = bytes_to_count(invoke_id);
    info$data_value = bytes_to_hex(data);
    ++info$write_count;
}

event ICCP::mms_write_response(c: connection, invoke_id: string,
                              results: string) {
    local info = set_session(c);
    info$service = "MMS_WRITE_RESP";
    info$invoke_id = bytes_to_count(invoke_id);
    emit_log(c);
}

event ICCP::mms_get_variable_access_attributes_request(c: connection,
                                                      invoke_id: string) {
    local info = set_session(c);
    info$service = "MMS_GET_VAR_ATTRS_REQ";
    info$invoke_id = bytes_to_count(invoke_id);
}

event ICCP::mms_get_variable_access_attributes_response(c: connection,
                                                       invoke_id: string,
                                                       deletable: count,
                                                       type_spec: string) {
    local info = set_session(c);
    info$service = "MMS_GET_VAR_ATTRS_RESP";
    info$invoke_id = bytes_to_count(invoke_id);
    info$data_type = bytes_to_hex(type_spec);
    emit_log(c);
}

############################################################################
# Object Name Event Handlers
############################################################################

event ICCP::mms_object_vmd_specific(c: connection, name: string) {
    local info = set_session(c);
    if ( info?$object_name )
        info$object_name += fmt(" VMD:%s", bytes_to_hex(name));
    else
        info$object_name = fmt("VMD:%s", bytes_to_hex(name));
}

event ICCP::mms_object_domain_specific(c: connection, domain_id: string,
                                      item_id: string) {
    local info = set_session(c);
    if ( info?$object_name )
        info$object_name += fmt(" DOM:%s/%s", bytes_to_string(domain_id),
                               bytes_to_string(item_id));
    else
        info$object_name = fmt("DOM:%s/%s", bytes_to_string(domain_id),
                              bytes_to_string(item_id));
}

event ICCP::mms_object_aa_specific(c: connection, name: string) {
    local info = set_session(c);
    if ( info?$object_name )
        info$object_name += fmt(" AA:%s", bytes_to_hex(name));
    else
        info$object_name = fmt("AA:%s", bytes_to_hex(name));
}

############################################################################
# Connection Cleanup
############################################################################

event connection_state_remove(c: connection) {
    if ( c?$iccp && c$iccp$service != "MMS_INITIATE_RESP" &&
         c$iccp$service != "COTP_CC" )
        emit_log(c);
}
