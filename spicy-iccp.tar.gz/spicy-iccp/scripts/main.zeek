##! ICCP/TASE.2 Protocol Analyzer for Zeek

module ICCP;

export {
    redef enum Log::ID += { LOG };
    
    type Info: record {
        ts: time &log;
        uid: string &log;
        id: conn_id &log;
        is_orig: bool &log;
        
        service: string &log &optional;
        invoke_id: count &log &optional;
        
        local_detail: count &log &optional;
        max_serv_out_calling: count &log &optional;
        max_serv_out_called: count &log &optional;
        nesting_level: count &log &optional;
        version_number: count &log &optional;
        
        vendor_name: string &log &optional;
        model_name: string &log &optional;
        revision: string &log &optional;
        
        object_class: count &log &optional;
        object_value: string &log &optional;
        
        cotp_src_ref: count &log &optional;
        cotp_dst_ref: count &log &optional;
        cotp_class: count &log &optional;
        
        read_count: count &log &default=0;
        write_count: count &log &default=0;
        get_name_list_count: count &log &default=0;
        identify_count: count &log &default=0;
    };
}

redef record connection += {
    iccp: Info &optional;
};

event zeek_init() &priority=5 {
    Log::create_stream(ICCP::LOG, [$columns=Info, $path="iccp"]);
}

function set_session(c: connection): Info {
    if ( ! c?$iccp ) {
        c$iccp = Info(
            $ts=network_time(),
            $uid=c$uid,
            $id=c$id,
            $is_orig=T
        );
    }
    return c$iccp;
}

function emit_log(c: connection) {
    if ( c?$iccp )
        Log::write(ICCP::LOG, c$iccp);
}

function bytes_to_string(data: string): string {
    local result = "";
    for ( i in data ) {
        local ch = data[i];
        if ( ch >= 0x20 && ch <= 0x7E )
            result += ch;
    }
    return result;
}

############################################################################
# COTP Event Handlers
############################################################################

event iccp_cotp_connection_request(c: connection, dst_ref: count,
                                   src_ref: count, class_option: count) {
    local info = set_session(c);
    info$service = "COTP_CR";
    info$cotp_src_ref = src_ref;
    info$cotp_dst_ref = dst_ref;
    info$cotp_class = class_option;
}

event iccp_cotp_connection_confirm(c: connection, dst_ref: count,
                                   src_ref: count, class_option: count) {
    local info = set_session(c);
    info$service = "COTP_CC";
    info$cotp_src_ref = src_ref;
    info$cotp_dst_ref = dst_ref;
    info$cotp_class = class_option;
    emit_log(c);
}

event iccp_cotp_disconnect_request(c: connection, dst_ref: count,
                                   src_ref: count, reason: count) {
    local info = set_session(c);
    info$service = "COTP_DR";
    info$cotp_src_ref = src_ref;
    info$cotp_dst_ref = dst_ref;
    emit_log(c);
}

event iccp_cotp_data(c: connection, tpdu_nr: count, eot: bool) {
    # Track COTP data segments if needed
}

############################################################################
# MMS Session Event Handlers
############################################################################

event iccp_mms_initiate_request(c: connection, local_detail: count,
                                max_serv_out_calling: count,
                                max_serv_out_called: count,
                                nesting_level: count, version: count,
                                param_cbb: string, services: string) {
    local info = set_session(c);
    info$service = "MMS_INITIATE_REQ";
    info$local_detail = local_detail;
    info$max_serv_out_calling = max_serv_out_calling;
    info$max_serv_out_called = max_serv_out_called;
    info$nesting_level = nesting_level;
    info$version_number = version;
}

event iccp_mms_initiate_response(c: connection, local_detail: count,
                                 max_serv_out_calling: count,
                                 max_serv_out_called: count,
                                 nesting_level: count, version: count,
                                 param_cbb: string, services: string) {
    local info = set_session(c);
    info$service = "MMS_INITIATE_RESP";
    info$local_detail = local_detail;
    info$max_serv_out_calling = max_serv_out_calling;
    info$max_serv_out_called = max_serv_out_called;
    info$nesting_level = nesting_level;
    info$version_number = version;
    emit_log(c);
}

event iccp_mms_conclude_request(c: connection) {
    local info = set_session(c);
    info$service = "MMS_CONCLUDE_REQ";
    emit_log(c);
}

event iccp_mms_conclude_response(c: connection) {
    local info = set_session(c);
    info$service = "MMS_CONCLUDE_RESP";
    emit_log(c);
}

############################################################################
# MMS Service Request Event Handlers
############################################################################

event iccp_mms_identify_request(c: connection, is_orig: bool,
                                invoke_id: string) {
    local info = set_session(c);
    info$service = "MMS_IDENTIFY_REQ";
    info$invoke_id = bytestring_to_count(invoke_id);
    info$is_orig = is_orig;
    ++info$identify_count;
}

event iccp_mms_identify_response(c: connection, is_orig: bool,
                                 invoke_id: string,
                                 vendor: string, model: string,
                                 revision: string) {
    local info = set_session(c);
    info$service = "MMS_IDENTIFY_RESP";
    info$invoke_id = bytestring_to_count(invoke_id);
    info$is_orig = is_orig;
    info$vendor_name = bytes_to_string(vendor);
    info$model_name = bytes_to_string(model);
    info$revision = bytes_to_string(revision);
    emit_log(c);
}

event iccp_mms_get_name_list_request(c: connection, is_orig: bool,
                                     invoke_id: string,
                                     object_class: count) {
    local info = set_session(c);
    info$service = "MMS_GET_NAME_LIST_REQ";
    info$invoke_id = bytestring_to_count(invoke_id);
    info$is_orig = is_orig;
    info$object_class = object_class;
    ++info$get_name_list_count;
}

event iccp_mms_get_name_list_response(c: connection, is_orig: bool,
                                      invoke_id: string,
                                      identifiers: string) {
    local info = set_session(c);
    info$service = "MMS_GET_NAME_LIST_RESP";
    info$invoke_id = bytestring_to_count(invoke_id);
    info$is_orig = is_orig;
    info$object_value = bytestring_to_hexstr(identifiers);
    emit_log(c);
}

event iccp_mms_read_request(c: connection, is_orig: bool,
                            invoke_id: string,
                            spec_with_result: count,
                            var_spec_data: string) {
    local info = set_session(c);
    info$service = "MMS_READ_REQ";
    info$invoke_id = bytestring_to_count(invoke_id);
    info$is_orig = is_orig;
    ++info$read_count;
}

event iccp_mms_read_response(c: connection, is_orig: bool,
                             invoke_id: string,
                             var_access_spec: count,
                             access_result: string) {
    local info = set_session(c);
    info$service = "MMS_READ_RESP";
    info$invoke_id = bytestring_to_count(invoke_id);
    info$is_orig = is_orig;
    info$object_value = bytestring_to_hexstr(access_result);
    emit_log(c);
}

event iccp_mms_write_request(c: connection, is_orig: bool,
                             invoke_id: string,
                             var_spec_data: string,
                             data: string) {
    local info = set_session(c);
    info$service = "MMS_WRITE_REQ";
    info$invoke_id = bytestring_to_count(invoke_id);
    info$is_orig = is_orig;
    info$object_value = bytestring_to_hexstr(data);
    ++info$write_count;
}

event iccp_mms_write_response(c: connection, is_orig: bool,
                              invoke_id: string,
                              results: string) {
    local info = set_session(c);
    info$service = "MMS_WRITE_RESP";
    info$invoke_id = bytestring_to_count(invoke_id);
    info$is_orig = is_orig;
    emit_log(c);
}

event connection_state_remove(c: connection) {
    if ( c?$iccp && c$iccp$service != "MMS_INITIATE_RESP" &&
         c$iccp$service != "COTP_CC" )
        emit_log(c);
}
