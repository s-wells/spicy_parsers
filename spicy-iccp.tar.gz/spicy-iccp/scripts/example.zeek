##! Example ICCP Monitoring Script
##! 
##! This script demonstrates basic usage of the spicy-iccp analyzer
##! for monitoring ICCP/TASE.2 traffic in a power grid control center.

@load spicy-iccp

module ICCPExample;

export {
    ## Enable verbose logging
    const verbose_logging = F &redef;
}

############################################################################
# Basic Event Monitoring
############################################################################

event ICCP::mms_initiate_request(c: connection, local_detail: count,
                                max_serv_out_calling: count,
                                max_serv_out_called: count,
                                nesting_level: count, version: count,
                                param_cbb: string, services: string) {
    if ( verbose_logging )
        print fmt("ICCP Session Initiated: %s -> %s (MMS v%d)",
                 c$id$orig_h, c$id$resp_h, version);
}

event ICCP::mms_identify_response(c: connection, invoke_id: string,
                                 vendor: string, model: string,
                                 revision: string) {
    # Extract readable strings
    local vendor_str = "";
    for ( i in vendor ) {
        if ( vendor[i] >= 0x20 && vendor[i] <= 0x7E )
            vendor_str += vendor[i];
    }
    
    local model_str = "";
    for ( i in model ) {
        if ( model[i] >= 0x20 && model[i] <= 0x7E )
            model_str += model[i];
    }
    
    if ( verbose_logging )
        print fmt("ICCP Device: %s - %s %s", c$id$resp_h, vendor_str, model_str);
}

event ICCP::mms_read_request(c: connection, invoke_id: string,
                            spec_with_result: count, var_spec_tag: count) {
    if ( verbose_logging )
        print fmt("ICCP Read: %s reading from %s (invoke_id: %d)",
                 c$id$orig_h, c$id$resp_h, bytestring_to_count(invoke_id));
}

event ICCP::mms_write_request(c: connection, invoke_id: string,
                             var_spec_tag: count, data: string) {
    print fmt("ICCP Write: %s writing to %s (invoke_id: %d, data_len: %d bytes)",
             c$id$orig_h, c$id$resp_h, bytestring_to_count(invoke_id), |data|);
}

############################################################################
# Statistics Reporting
############################################################################

global connection_stats: table[addr, addr] of count &create_expire=1hr &default=0;

event ICCP::mms_read_request(c: connection, invoke_id: string,
                            spec_with_result: count, var_spec_tag: count) {
    ++connection_stats[c$id$orig_h, c$id$resp_h];
}

event zeek_done() {
    if ( |connection_stats| == 0 )
        return;
    
    print "\n=== ICCP Traffic Summary ===";
    for ( [orig, resp] in connection_stats ) {
        print fmt("%s -> %s: %d operations", orig, resp, connection_stats[orig, resp]);
    }
}
