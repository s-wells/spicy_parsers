# spicy-iccp

A Zeek protocol analyzer for ICCP/TASE.2 (Inter-Control Center Communications Protocol) using Spicy.

## Overview

ICCP (IEC 60870-6-503), also known as TASE.2 (Telecontrol Application Service Element 2), is widely used for real-time data exchange between control centers in power system operations. This analyzer provides deep packet inspection for ICCP traffic running over the MMS (Manufacturing Message Specification) protocol stack.

### Protocol Stack

```
ICCP/TASE.2 Application
    ↓
MMS (ISO 9506)
    ↓
COTP (ISO 8073)
    ↓
TPKT (RFC 1006)
    ↓
TCP Port 102
```

## Features

- Complete TPKT/COTP/MMS stack parsing
- MMS session establishment and management
- MMS service operations: Read, Write, GetNameList, Identify
- Connection state tracking
- Device identification extraction
- Comprehensive logging with operation statistics

## Installation

### Prerequisites

- Zeek >= 6.0
- Spicy >= 1.8
- CMake >= 3.15

### Using Zeek Package Manager

```bash
zkg install spicy-iccp
```

### Manual Installation

```bash
# Clone or extract the package
cd spicy-iccp

# Configure
./configure --zeek-dist=$(zeek-config --zeek_dist)

# Build and install
cd build
cmake --build .
cmake --build . --target install
```

### Verify Installation

```bash
zeek -NN Zeek::Spicy_ICCP

# Expected output:
# Zeek::Spicy_ICCP - ICCP/TASE.2 Protocol Analyzer (built-in)
```

## Usage

### Basic Usage

```bash
# Analyze PCAP file
zeek -Cr traffic.pcap spicy-iccp

# Live capture on interface
zeek -i eth0 spicy-iccp

# With local site policy
zeek -i eth0 local spicy-iccp
```

### Custom Configuration

Create a local script:

```zeek
@load spicy-iccp

# The analyzer automatically registers for port 102/tcp
# To add additional ports:
redef Analyzer::disabled_analyzers += { Analyzer::ANALYZER_ICCP };

event zeek_init() {
    Analyzer::register_for_ports(Analyzer::ANALYZER_ICCP, set(102/tcp, 2404/tcp));
}
```

## Log Output

### iccp.log

The analyzer creates an `iccp.log` file with the following fields:

| Field | Type | Description |
|-------|------|-------------|
| ts | time | Timestamp |
| uid | string | Connection UID |
| id | conn_id | Connection 4-tuple |
| is_orig | bool | Direction flag |
| service | string | Service type (e.g., MMS_READ_REQ) |
| invoke_id | count | MMS invoke identifier |
| local_detail | count | MMS session local detail |
| max_serv_out_calling | count | Max services outstanding (calling) |
| max_serv_out_called | count | Max services outstanding (called) |
| nesting_level | count | Data structure nesting level |
| version_number | count | MMS version |
| vendor_name | string | Device vendor |
| model_name | string | Device model |
| revision | string | Device revision |
| object_class | count | MMS object class |
| object_value | string | Object value (hex) |
| cotp_src_ref | count | COTP source reference |
| cotp_dst_ref | count | COTP destination reference |
| cotp_class | count | COTP class |
| read_count | count | Total reads |
| write_count | count | Total writes |
| get_name_list_count | count | Total name list queries |
| identify_count | count | Total identify requests |

### Example Log Entry

```
1704067200.000000  CHhAvVGS1DHFjwGM9  192.168.1.10  49152  192.168.1.20  102  T  MMS_INITIATE_RESP  -  1  5  5  3  1  -  -  -  -  -  1234  5678  0  0  0  0  0
```

## Events

The analyzer generates the following Zeek events:

### COTP Events
- `iccp_cotp_connection_request`
- `iccp_cotp_connection_confirm`
- `iccp_cotp_disconnect_request`
- `iccp_cotp_data`

### MMS Session Events
- `iccp_mms_initiate_request`
- `iccp_mms_initiate_response`
- `iccp_mms_conclude_request`
- `iccp_mms_conclude_response`

### MMS Service Events
- `iccp_mms_identify_request`
- `iccp_mms_identify_response`
- `iccp_mms_get_name_list_request`
- `iccp_mms_get_name_list_response`
- `iccp_mms_read_request`
- `iccp_mms_read_response`
- `iccp_mms_write_request`
- `iccp_mms_write_response`

### Example Event Handler

```zeek
@load spicy-iccp

event iccp_mms_write_request(c: connection, is_orig: bool,
                             invoke_id: string,
                             var_spec_data: string,
                             data: string) {
    print fmt("ICCP Write: %s -> %s", c$id$orig_h, c$id$resp_h);
}
```

## Security Monitoring

Example security monitoring script:

```zeek
@load spicy-iccp
@load base/frameworks/notice

module ICCPSecurity;

export {
    redef enum Notice::Type += {
        ICCP_Unauthorized_Write,
    };
    
    const authorized_controllers: set[addr] = {
        192.168.1.10,
    } &redef;
}

event iccp_mms_write_request(c: connection, is_orig: bool,
                             invoke_id: string,
                             var_spec_data: string,
                             data: string) {
    if ( c$id$orig_h !in authorized_controllers ) {
        NOTICE([$note=ICCP_Unauthorized_Write,
                $conn=c,
                $msg=fmt("Unauthorized ICCP write from %s", c$id$orig_h)]);
    }
}
```

## Protocol Details

### MMS Services Supported

- **Initiate/Conclude**: Session management
- **Identify**: Device identification (vendor, model, revision)
- **GetNameList**: Object enumeration
- **Read**: Data value retrieval
- **Write**: Data value modification

### COTP Operations

- Connection Request (CR) / Connection Confirm (CC)
- Disconnect Request (DR)
- Data Transfer (DT) with End-of-TSDU tracking

## Testing

```bash
cd tests
btest -d
```

## Troubleshooting

### Analyzer Not Detected

```bash
# Check Spicy is installed
spicyz --version

# Check plugin loaded
zeek -NN | grep Spicy_ICCP

# Rebuild if necessary
cd build && cmake --build . --target install
```

### No Log Output

```bash
# Enable debug output
zeek -Cr traffic.pcap spicy-iccp Spicy::enable_print=T

# Check for ICCP traffic
tcpdump -r traffic.pcap 'tcp port 102'
```

## Project Structure

```
spicy-iccp/
├── analyzer/
│   ├── iccp.spicy      # Protocol grammar
│   └── iccp.evt        # Event definitions with protocol analyzer
├── scripts/
│   ├── main.zeek       # Event handlers and logging
│   └── __load__.zeek   # Package loader
├── tests/              # Test suite
├── CMakeLists.txt      # Build configuration
├── configure           # Configuration script
└── zkg.meta           # Package metadata
```

## References

- [IEC 60870-6-503: TASE.2/ICCP](https://webstore.iec.ch/publication/3745)
- [ISO 9506: MMS](https://www.iso.org/standard/16164.html)
- [Zeek Documentation](https://docs.zeek.org)
- [Spicy Documentation](https://docs.zeek.org/projects/spicy)
- [Zeek Plugin Tutorial](https://docs.zeek.org/en/v8.0.0/devel/spicy/tutorial.html)

## License

BSD 3-Clause License

## Support

For issues and questions:
- GitHub Issues
- Zeek Community: https://community.zeek.org

## Changelog

### v1.0.0
- Initial release
- Complete TPKT/COTP/MMS parsing
- Core MMS services support
- Connection tracking
- Comprehensive logging
